package com.example.mapsbleforwarder

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.mapsbleforwarder.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val all = grants.values.all { it }
        toast(if (all) "Đã cấp quyền" else "Thiếu quyền")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGrantNotif.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.btnScanConnect.setOnClickListener {
            ensureBtPermsThen {
                BleManager.init(this)
                BleManager.scanAndConnect(
                    deviceName = "ESP32C3_OLED",
                    onStatus = { runOnUiThread { binding.txtStatus.text = it } }
                )
            }
        }

        binding.btnSend.setOnClickListener {
            val text = binding.edtManual.text.toString().ifBlank { "Hello ESP32C3" }
            BleManager.writeText(text) { ok ->
                runOnUiThread { toast(if (ok) "Đã gửi" else "Gửi lỗi") }
            }
        }
    }

    private fun ensureBtPermsThen(block: () -> Unit) {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms += Manifest.permission.BLUETOOTH_SCAN
            perms += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            perms += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        val need = perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need) permissionLauncher.launch(perms.toTypedArray()) else block()
    }

    private fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
