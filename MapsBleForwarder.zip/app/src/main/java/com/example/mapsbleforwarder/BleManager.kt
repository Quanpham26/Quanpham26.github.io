package com.example.mapsbleforwarder

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.nio.charset.Charset
import java.util.*

object BleManager {
    private lateinit var context: Context
    private val main = Handler(Looper.getMainLooper())

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var pendingChunks: ArrayDeque<ByteArray> = ArrayDeque()

    private val SERVICE_UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    private val CHAR_UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

    fun init(ctx: Context) {
        context = ctx.applicationContext
        val mgr = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = mgr.adapter
    }

    fun scanAndConnect(deviceName: String, onStatus: (String) -> Unit) {
        val adapter = bluetoothAdapter ?: return onStatus("Bluetooth adapter null")
        onStatus("Scanning…")

        val scanner = adapter.bluetoothLeScanner
        val filters = listOf(ScanFilter.Builder().setDeviceName(deviceName).build())
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()

        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                if (result.device.name == deviceName) {
                    onStatus("Found $deviceName, connecting…")
                    scanner.stopScan(this)
                    connect(result.device, onStatus)
                }
            }

            override fun onScanFailed(errorCode: Int) {
                onStatus("Scan failed: $errorCode")
            }
        }

        scanner.startScan(filters, settings, cb)
        main.postDelayed({
            try { scanner.stopScan(cb) } catch (_: Exception) {}
        }, 15000)
    }

    private fun connect(device: BluetoothDevice, onStatus: (String) -> Unit) {
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else device.connectGatt(context, false, gattCallback)
        onStatus("Connecting GATT…")
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                writeChar = null
                pendingChunks.clear()
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val svc = gatt.getService(SERVICE_UUID) ?: return
            writeChar = svc.getCharacteristic(CHAR_UUID)
            writeChar?.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            sendNextChunk()
        }
    }

    fun writeText(text: String, done: (Boolean) -> Unit = {}) {
        val g = gatt ?: return done(false)
        val ch = writeChar ?: return done(false)

        val bytes = text.toByteArray(Charset.forName("UTF-8"))
        pendingChunks.clear()
        var i = 0
        while (i < bytes.size) {
            val end = minOf(i + 20, bytes.size)
            pendingChunks.add(bytes.copyOfRange(i, end))
            i = end
        }
        this.onWriteDone = done
        sendNextPrepared(g, ch)
    }

    private var onWriteDone: (Boolean) -> Unit = {}

    private fun sendNextPrepared(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (pendingChunks.isEmpty()) return onWriteDone(true)
        ch.value = pendingChunks.removeFirst()
        val ok = g.writeCharacteristic(ch)
        if (!ok) onWriteDone(false)
    }

    private fun sendNextChunk() {
        val g = gatt ?: return
        val ch = writeChar ?: return
        if (pendingChunks.isEmpty()) return onWriteDone(true)
        ch.value = pendingChunks.removeFirst()
        val ok = g.writeCharacteristic(ch)
        if (!ok) onWriteDone(false)
    }
}
