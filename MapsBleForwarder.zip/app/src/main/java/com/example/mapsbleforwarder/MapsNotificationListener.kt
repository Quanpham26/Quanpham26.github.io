package com.example.mapsbleforwarder

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MapsNotificationListener : NotificationListenerService() {
    private val mapsPkg = "com.google.android.apps.maps"

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != mapsPkg) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        val msg = (if (text.isNotBlank()) text else title).take(160)
        BleManager.writeText(msg) { }
    }
}
